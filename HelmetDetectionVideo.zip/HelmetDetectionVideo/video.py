from collections import defaultdict

import cv2
import numpy as np

from ultralytics import YOLO


model = YOLO('best.pt')

# Define the font parameters
org1 = (20, 80)
org2 = (20, 50)
org3 = (20, 110)
font_face = cv2.FONT_HERSHEY_SIMPLEX
font_scale = 1
font_scale2 = 0.2
font_color = (0, 0, 255)  # Red
font_color1 = (0, 255, 0)  # Red
font_thickness = 2
line_type = cv2.LINE_AA

# Open the video file
video_path = "SampleVideoFilesofMotorcyclists/video3.mp4"
cap = cv2.VideoCapture(video_path) # if have to use camera give 0 for front camera / 1 for external camera

# Loop through the video frames
while cap.isOpened():
    # Read a frame from the video
    success, frame = cap.read()

    if success:

        results = model.predict(frame,conf=0.1)
    # Visualize the results on the frame
    annotated_frame = results[0].plot()
    Helmet = ""
    No_Helmet = ""
    if (results[0].boxes) is None:
            Count = 0
    else:
            Count = len(results[0].boxes)
            print("Detected objects",results[0].boxes.cls)
            if 1 in results[0].boxes.cls:
                    Helmet = "Helmet Detected"
            else:
                    No_Helmet = "No Helmet Detected"
                    
    cv2.putText(annotated_frame, f"Object count:{Count}", org1, font_face, font_scale, font_color, font_thickness, line_type)
    cv2.putText(annotated_frame, f"{Helmet}", org2, font_face, font_scale, font_color1, font_thickness, line_type)
    cv2.putText(annotated_frame, f"{No_Helmet}", org2, font_face, font_scale, font_color, font_thickness, line_type)

            # Display the annotated frame
    cv2.imshow("Helmet Detection Interface", annotated_frame)
    # Break the loop if 'q' is pressed
    if cv2.waitKey(10) & 0xFF == ord("q"):
            break

cap.release()

cv2.destroyAllWindows()